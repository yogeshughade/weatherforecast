using MyClassLib;
using Xunit;

public class WeatherServiceTests
{
    [Fact]
    public void GetForecast_ShouldReturnFiveDays()
    {
        var service = new WeatherService();
        var result = service.GetForecast().ToList();
        Assert.Equal(5, result.Count);
    }
}
